const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('kreatoCRM', {
  getContacts:    ()        => ipcRenderer.invoke('contacts:get'),
  addContact:     (c)       => ipcRenderer.invoke('contacts:add', c),
  updateContact:  (c)       => ipcRenderer.invoke('contacts:update', c),
  deleteContact:  (id)      => ipcRenderer.invoke('contacts:delete', id),
  addHistory:     (data)    => ipcRenderer.invoke('contacts:addHistory', data),
  minimize: () => ipcRenderer.send('win:minimize'),
  maximize: () => ipcRenderer.send('win:maximize'),
  close:    () => ipcRenderer.send('win:close'),
});