const { app, BrowserWindow, ipcMain, session } = require('electron');
const path = require('path');
const Store = require('electron-store');

const store = new Store({
  defaults: {
    contacts: [
      { id: 1, nombre: 'Codent Dental', giro: 'Dentista', telefono: '3312345678', status: 'interesado', ciudad: 'Guadalajara', notas: 'Muy interesado. Llamar para cerrar.', historial: [] },
      { id: 2, nombre: 'El Sillón Peluquerías', giro: 'Peluquería', telefono: '3338252072', status: 'contactado', ciudad: 'Guadalajara', notas: 'Contactado por teléfono.', historial: [] },
      { id: 3, nombre: 'Dr. Ricardo Hernández', giro: 'Médico', telefono: '', status: 'contactado', ciudad: 'Guadalajara', notas: 'Correo enviado. Sin respuesta.', historial: [] },
    ],
    nextId: 4,
  }
});

let mainWindow = null;

function fixWhatsAppSession() {
  const waSession = session.fromPartition('persist:kreatu-wa');

  // Quita headers que bloquean WhatsApp Web dentro de Electron
  waSession.webRequest.onHeadersReceived((details, callback) => {
    const headers = { ...details.responseHeaders };
    delete headers['x-frame-options'];
    delete headers['X-Frame-Options'];
    delete headers['content-security-policy'];
    delete headers['Content-Security-Policy'];
    delete headers['cross-origin-opener-policy'];
    delete headers['Cross-Origin-Opener-Policy'];
    delete headers['cross-origin-embedder-policy'];
    delete headers['Cross-Origin-Embedder-Policy'];
    callback({ responseHeaders: headers });
  });

  // User agent de Chrome real para que WA Web no detecte Electron
  waSession.webRequest.onBeforeSendHeaders((details, callback) => {
    const headers = { ...details.requestHeaders };
    headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    headers['Accept-Language'] = 'es-MX,es;q=0.9';
    callback({ requestHeaders: headers });
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1350,
    height: 800,
    minWidth: 1000,
    minHeight: 600,
    frame: false,
    backgroundColor: '#0f1117',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webviewTag: true,
      webSecurity: false,
    },
    title: 'Kreatu CRM',
  });

  mainWindow.loadFile(path.join(__dirname, 'src/index.html'));
}

app.whenReady().then(() => {
  fixWhatsAppSession();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ── IPC Contactos ─────────────────────────────────────────────────────────────
ipcMain.handle('contacts:get', () => store.get('contacts'));

ipcMain.handle('contacts:add', (_, contact) => {
  const id = store.get('nextId');
  const newContact = { ...contact, id, historial: [] };
  store.set('contacts', [...store.get('contacts'), newContact]);
  store.set('nextId', id + 1);
  return newContact;
});

ipcMain.handle('contacts:update', (_, updated) => {
  const contacts = store.get('contacts').map(c =>
    c.id === updated.id ? { ...c, ...updated } : c
  );
  store.set('contacts', contacts);
  return true;
});

ipcMain.handle('contacts:delete', (_, id) => {
  store.set('contacts', store.get('contacts').filter(c => c.id !== id));
  return true;
});

ipcMain.handle('contacts:addHistory', (_, { id, entry }) => {
  const contacts = store.get('contacts');
  const idx = contacts.findIndex(c => c.id === id);
  if (idx !== -1) {
    contacts[idx].historial = contacts[idx].historial || [];
    contacts[idx].historial.push(entry);
    store.set('contacts', contacts);
  }
  return true;
});

// ── IPC Ventana ───────────────────────────────────────────────────────────────
ipcMain.on('win:minimize', () => mainWindow?.minimize());
ipcMain.on('win:maximize', () =>
  mainWindow?.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize()
);
ipcMain.on('win:close', () => mainWindow?.close());