const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('kreatoCRM', {
  // Contactos
  getContacts:    ()         => ipcRenderer.invoke('contacts:get'),
  addContact:     (c)        => ipcRenderer.invoke('contacts:add', c),
  updateContact:  (c)        => ipcRenderer.invoke('contacts:update', c),
  deleteContact:  (id)       => ipcRenderer.invoke('contacts:delete', id),

  // WhatsApp
  sendWA:         (data)     => ipcRenderer.invoke('wa:send', data),
  waStatus:       ()         => ipcRenderer.invoke('wa:status'),
  waReconnect:    ()         => ipcRenderer.invoke('wa:reconnect'),

  // Eventos entrantes
  onWaQR:         (cb)  => ipcRenderer.on('wa:qr',         (_, d) => cb(d)),
  onWaReady:      (cb)  => ipcRenderer.on('wa:ready',      (_, d) => cb(d)),
  onWaStatus:     (cb)  => ipcRenderer.on('wa:status',     (_, d) => cb(d)),
  onWaMessageIn:  (cb)  => ipcRenderer.on('wa:message_in', (_, d) => cb(d)),

  // Ventana
  minimize: () => ipcRenderer.send('win:minimize'),
  maximize: () => ipcRenderer.send('win:maximize'),
  close:    () => ipcRenderer.send('win:close'),
});
