const { app, BrowserWindow, ipcMain, Notification } = require('electron');
const path = require('path');
const Store = require('electron-store');
const qrcode = require('qrcode');

// ── Persistencia local ──────────────────────────────────────────────────────
const store = new Store({
  defaults: {
    contacts: [
      { id: 1, nombre: 'Codent Dental', giro: 'Dentista', telefono: '3312345678', status: 'interesado', ciudad: 'Guadalajara', notas: 'Muy interesado. Llamar para cerrar.', historial: [] },
      { id: 2, nombre: 'El Sillón Peluquerías', giro: 'Peluquería', telefono: '3338252072', status: 'contactado', ciudad: 'Guadalajara', notas: 'Contactado por teléfono.', historial: [] },
      { id: 3, nombre: 'Dr. Ricardo Hernández', giro: 'Médico', telefono: '', status: 'contactado', ciudad: 'Guadalajara', notas: 'Correo enviado. Sin respuesta.', historial: [] },
    ],
    nextId: 4,
  }
});

let mainWindow = null;
let waClient = null;
let waReady = false;

// ── Ventana principal ────────────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 780,
    minWidth: 960,
    minHeight: 600,
    frame: false,
    backgroundColor: '#0f1117',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
    icon: path.join(__dirname, 'src/assets/icon.ico'),
    title: 'Kreatu CRM',
  });

  mainWindow.loadFile(path.join(__dirname, 'src/index.html'));
}

app.whenReady().then(() => {
  createWindow();
  initWhatsApp();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ── WhatsApp Web.js ──────────────────────────────────────────────────────────
function initWhatsApp() {
  try {
    const { Client, LocalAuth } = require('whatsapp-web.js');

    waClient = new Client({
      authStrategy: new LocalAuth({ dataPath: path.join(app.getPath('userData'), 'wa-session') }),
      puppeteer: {
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
      },
    });

    waClient.on('qr', async (qr) => {
      const qrDataUrl = await qrcode.toDataURL(qr, { width: 280, margin: 2 });
      mainWindow?.webContents.send('wa:qr', qrDataUrl);
    });

    waClient.on('ready', () => {
      waReady = true;
      mainWindow?.webContents.send('wa:ready', { phone: waClient.info?.wid?.user });
    });

    waClient.on('authenticated', () => {
      mainWindow?.webContents.send('wa:status', 'authenticated');
    });

    waClient.on('auth_failure', () => {
      waReady = false;
      mainWindow?.webContents.send('wa:status', 'auth_failure');
    });

    waClient.on('disconnected', () => {
      waReady = false;
      mainWindow?.webContents.send('wa:status', 'disconnected');
    });

    waClient.on('message', async (msg) => {
      const from = msg.from.replace('@c.us', '').replace('52', '');
      mainWindow?.webContents.send('wa:message_in', {
        from,
        body: msg.body,
        timestamp: msg.timestamp,
      });
    });

    waClient.initialize();
  } catch (err) {
    console.error('WhatsApp init error:', err);
    mainWindow?.webContents.send('wa:status', 'error');
  }
}

// ── IPC: Contactos ────────────────────────────────────────────────────────────
ipcMain.handle('contacts:get', () => store.get('contacts'));

ipcMain.handle('contacts:add', (_, contact) => {
  const id = store.get('nextId');
  const newContact = { ...contact, id, historial: [] };
  store.set('contacts', [...store.get('contacts'), newContact]);
  store.set('nextId', id + 1);
  return newContact;
});

ipcMain.handle('contacts:update', (_, updated) => {
  const contacts = store.get('contacts').map(c => c.id === updated.id ? { ...c, ...updated } : c);
  store.set('contacts', contacts);
  return true;
});

ipcMain.handle('contacts:delete', (_, id) => {
  store.set('contacts', store.get('contacts').filter(c => c.id !== id));
  return true;
});

// ── IPC: WhatsApp ─────────────────────────────────────────────────────────────
ipcMain.handle('wa:send', async (_, { phone, message }) => {
  if (!waReady || !waClient) return { ok: false, error: 'WhatsApp no conectado' };
  try {
    const num = phone.replace(/\D/g, '');
    const chatId = `52${num}@c.us`;
    await waClient.sendMessage(chatId, message);

    // Guardar en historial del contacto
    const contacts = store.get('contacts');
    const idx = contacts.findIndex(c => c.telefono.replace(/\D/g,'') === num);
    if (idx !== -1) {
      contacts[idx].historial = contacts[idx].historial || [];
      contacts[idx].historial.push({ tipo: 'enviado', texto: message, fecha: Date.now() });
      store.set('contacts', contacts);
    }

    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

ipcMain.handle('wa:status', () => ({ ready: waReady }));

ipcMain.handle('wa:reconnect', () => {
  if (waClient) { try { waClient.destroy(); } catch(_) {} }
  waReady = false;
  initWhatsApp();
  return true;
});

// ── IPC: Ventana (titlebar custom) ────────────────────────────────────────────
ipcMain.on('win:minimize', () => mainWindow?.minimize());
ipcMain.on('win:maximize', () => mainWindow?.isMaximized() ? mainWindow.unmaximize() : mainWindow.maximize());
ipcMain.on('win:close', () => mainWindow?.close());
