# 🟢 Kreatu CRM — WhatsApp Business Desktop

Aplicación de escritorio para Windows que conecta con WhatsApp Business
y te permite clasificar prospectos y mandar mensajes directo desde el CRM.

---

## ⚡ Instalación rápida (primera vez)

### Requisitos
- Windows 10 / 11 (64-bit)
- Node.js 18 o superior → https://nodejs.org/
- Git (opcional)

### Pasos

```bash
# 1. Entra a la carpeta del proyecto
cd kreatu-crm

# 2. Instala dependencias (solo la primera vez, tarda ~3 min)
npm install

# 3. Arranca la app
npm start
```

---

## 📱 Conectar WhatsApp Business

1. Abre la app con `npm start`
2. Verás un código QR en el panel derecho
3. En tu celular: Abre **WhatsApp Business** → ⋮ Menú → **Dispositivos vinculados** → **Vincular un dispositivo**
4. Escanea el QR
5. ¡Listo! La app dirá "WhatsApp conectado" ✅

> La sesión se guarda automáticamente. La próxima vez que abras la app
> ya no necesitas escanear el QR (a menos que cierres sesión en el celular).

---

## 🚀 Cómo usar el CRM

### Agregar contactos
- Clic en **"+ Nuevo contacto"** en el sidebar
- Llena nombre, giro (dentista, médico, etc.), teléfono y ciudad

### Clasificar estado
- Selecciona un contacto → cambia su estado:
  - 🔵 **Nuevo** → recién agregado
  - 🟡 **Contactado** → ya le mandaste mensaje
  - 🟢 **Interesado** → mostró interés
  - 🌿 **¡Cerrado!** → vendiste 🎉
  - 🔴 **No interesado** → descartado

### Enviar mensajes
- Selecciona el contacto
- En el panel derecho elige el tipo:
  - **🧊 Frío** → primer contacto
  - **📞 Seguimiento** → ya lo contactaste antes
  - **✅ Cierre** → listo para vender
- Clic en **"Enviar por WA"** (con WhatsApp conectado)
- O **"Copiar"** para pegar en WhatsApp Web

### Templates por giro
Los mensajes cambian automáticamente según el giro del prospecto:
- Dentista / Odontólogo → mensaje dental
- Médico → mensaje médico
- Salón / Spa / Peluquería → mensaje de belleza
- Cualquier otro → mensaje general

---

## 📦 Generar instalador .exe (opcional)

```bash
npm run build:win
```

El instalador quedará en la carpeta `dist/` listo para instalar en cualquier PC.

---

## 🗂️ Dónde se guarda la información

Los contactos se guardan localmente en:
```
C:\Users\[TU_USUARIO]\AppData\Roaming\kreatu-crm\config.json
```

No se sube a ningún servidor. Todo queda en tu PC.

---

## ❓ Problemas comunes

**El QR no aparece / error de Chromium**
→ Ejecuta `npm install` de nuevo

**WhatsApp se desconecta**
→ Clic en "🔄 Reconectar" en la app

**Error "Cannot find module"**
→ Borra la carpeta `node_modules` y ejecuta `npm install` de nuevo

---

*KreatuSitioWeb — projectmannager@kreatusitioweb.com*
